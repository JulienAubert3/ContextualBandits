#  ______                 _ _ _   
# | ___ \               | (_) |  
# | |_/ / __ _ _ __   __| |_| |_ 
# | ___ \/ _` | '_ \ / _` | | __|
# | |_/ / (_| | | | | (_| | | |_ 
# \____/ \__,_|_| |_|\__,_|_|\__|

################################################################################
#
#                             Environment settings
#
################################################################################

################################## Directory ###################################


## Set your working directory
setwd('./ContextualBanditsCode')

################################### Packages ###################################

# install.packages('DEoptim') 
library(DEoptim) # Enable to use Differential Evolution algorithm for global
# optimization
# install.packages('crayon') 
library(crayon) # Enable highlighting matrices elements
# install.packages('magrittr') 
library(magrittr)# Enable operations to be sequenced between several functions
# install.packages('dplyr')
library(dplyr)
#install.packages('tidyr')
library(tidyr)
library(ggplot2)
#install.packages('gridExtra')
library(gridExtra)

############################## Overall settings ################################

rm(list = ls())
set.seed(12)


################################################################################
#
#                                 Functions
#
################################################################################


################################################################################

# The purpose of this function is to filter the contexts of all participants at
# a time. This basically add as many columns as contexts exist and encode them
# with number from 1 to the maximum number of context inside one model.

FilterContext <- function(data, contexts) {
  
  context_names <- names(contexts)
  
  assign_context <- function(item, context) {
    for (l in seq_along(context)) {
      if (item %in% context[[l]]) {
        return(l)
      }
    }
    return(NA)
  }
  
  apply_context <- function(data_subset, context, context_name) {
    context_values <- sapply(data_subset$Item, assign_context, context=context)
    data_subset[[context_name]] <- context_values
    return(data_subset)
  }

  data <- lapply(data, function(data_subset) {
    for (i in seq_along(contexts)) {
      data_subset <- apply_context(data_subset, contexts[[i]], context_names[i])
    }
    return(data_subset)
  })
  
  return(data)
}

################################################################################

# The purpose of this function is to partition the data for each participant 
# into the different context for a specific model i.e. "OnePerContext" or
# "PlainBlue_Exceptions".

PartitionningData <- function(data, model_name) {
  
  unique_values <- sort(unique(data[[model_name]])) # Searching and sorting each
  # value of contexts to partition the data
  
  partitions <- lapply(unique_values, function(value) {
    
    subset <- data[data[[model_name]] == value, ]
    subset
  } ) # Partition the data based on unique values of the specified model column.
  
  partitions <- lapply(partitions, function(data) {
    
    data[, c("Action", "Reward", "Item", model_name), drop = FALSE]
  } ) # Select specific columns from each partitioned dataset.
  
  return(partitions)
  
}

################################################################################

BanditAlgo <- function(bandit_type = 'Exp3', data, eta, gamma = 0) {
  
  num_trials <- length(data[,'Action'])
  
  chosen_arms <- data[,'Action']
  
  num_arms <-  2 #length(unique(data[,'Action'])) 
  
  vec_prob <- rep(1/num_arms, num_arms)
  
  mat_prob <- matrix(vec_prob, ncol = num_arms, nrow = num_trials)
  
  cumulative_reward <- rep(0, num_arms)
  
  for (i in 2:num_trials) {
    
    reward <- data[i-1,'Reward']
    
    current_arm <- chosen_arms[i-1]
    
    switch(bandit_type,
           
           'Exp3' = {
             cumulative_reward[current_arm] <- cumulative_reward[current_arm] + 
               (reward / vec_prob[current_arm])
             weighted_sum <- sum(exp(eta * cumulative_reward)) 
             vec_prob <- exp(eta * cumulative_reward) / weighted_sum
           },
           
           'Gradient' = {
             cumulative_reward <- cumulative_reward + 
               ((replace(rep(0,num_arms), current_arm, 1) - vec_prob) * reward)
             weighted_sum <- sum(exp(eta * cumulative_reward))
             vec_prob <- exp(eta * cumulative_reward) / weighted_sum
           },
           
           'Exp-IX' = {
             cumulative_reward[current_arm] <- cumulative_reward[current_arm] + 
               (reward / (vec_prob[current_arm] + gamma))
             weighted_sum <- sum(exp(eta * cumulative_reward)) 
             vec_prob <- exp(eta * cumulative_reward) / weighted_sum
             
           } )
    
    mat_prob[i,] <- vec_prob
    
  }
  
  return(mat_prob)
  
}

################################################################################

# The purpose of this function is to create synthetic sequences of objects. To
# each new sequence of objects, we associate a synthetic agent which we will use
# to generate actions from the algorithms GenBanditAlgo.

GenDataSequence <- function(num_trials, num_synt_agents,
                            contexts = c(1:2, 7:8, 11:15)) {
  
  init_col <- rep(1, num_trials)
  
  context_sequences <- matrix(sample(contexts,
                                     size = num_trials * num_synt_agents,
                                     replace = TRUE),
                              nrow = num_trials)
  
  syntheticagents_list <- lapply(1:num_synt_agents, function(i) {
    
    simulated_data <- data.frame(Action = init_col,
                                 Reward = init_col,
                                 Item = context_sequences[, i])
    return(simulated_data)
    
  } )
  
  names(syntheticagents_list) <- paste("SyntheticAgent_", 1:num_synt_agents,
                                       sep = "")
  
  return(syntheticagents_list)
  
}

################################################################################

# The purpose of this function is to create file with items that would be
# presented to participant. This, to design synthetic agent on which we run
# simulations.

GenDataFilebis <- function(num_trials, num_synt_agents, working_dirs,
                        contexts = c(1:2, 7:8, 11:15)) {
  
  num_repetitions <- ceiling(num_trials / length(sample(contexts, 9,
                                                        replace = FALSE)))
  
  final_sample <- rep(contexts, times = num_repetitions)[1:num_trials]
  
  for (working_dir in working_dirs) {
    
    if (!dir.exists(working_dir)) {
      
      stop("Directory does not exist: ", working_dir)
      
    }
    
    for (i in 1:num_synt_agents) {
      
      data <- data.frame(Action = rep(0, num_trials),
                         Reward = rep(0, num_trials),
                         Item = final_sample)
      
      file_name <- paste0("databis_", i, ".csv")
      
      file_path <- file.path(working_dir, file_name)
      
      write.csv(data, file = file_path, row.names = FALSE)
      
    }
    
  }
  
  print("Files created!")
  
}

################################################################################

# This function gives the classification rule, ie the reward for each object
# as a function of the category.

CodingReward <- function(correct_choice = 1, wrong_choice = 0,
                         items = c(1:2, 7:8, 11:15)) {

  is_cat_A <- items %in% c(1, 2, 7, 13)
  
  cat_A <- ifelse(is_cat_A, wrong_choice, correct_choice)
  
  cat_B <- ifelse(is_cat_A, correct_choice, wrong_choice)

  reward_df <- data.frame(Item = items, A = cat_A, B = cat_B)
  
  return(reward_df)
}

################################################################################
# This function generates the choices for some dataframe 'data' of a synthetic 
# agent in a subset of a partition.


GenBanditAlgo <- function(bandit_type = 'Exp3', data, eta, gamma = 0,
                          reward_df) {
  
  num_trials <- length(data[,'Action'])
  num_arms <-  2 
  
  vec_prob <- rep(1/num_arms, num_arms)
  mat_prob <- matrix(vec_prob, ncol = num_arms, nrow = num_trials)
  
  cumulative_reward <- rep(0, num_arms)
  
  picked_arm <- sample(1:num_arms, 1, prob = vec_prob, replace = TRUE)
  chosen_arms <- rep(picked_arm, num_trials)
  
  object <- data[1,'Item']
  current_reward <- reward_df[reward_df$Item == object, picked_arm]
  reward_list <- rep(current_reward, num_trials)
  
  for (i in 2:num_trials) {
    
    switch(bandit_type,
           'Exp3' = {
             cumulative_reward[picked_arm] <- cumulative_reward[picked_arm] + 
               (current_reward / vec_prob[picked_arm])
             weighted_sum <- sum(exp(eta * cumulative_reward)) 
             vec_prob <- exp(eta * cumulative_reward) / weighted_sum
           },
           'Gradient' = {
             cumulative_reward <- cumulative_reward + 
               ((replace(rep(0,num_arms), picked_arm, 1) - vec_prob) *
                  current_reward)
             weighted_sum <- sum(exp(eta * cumulative_reward))
             vec_prob <- exp(eta * cumulative_reward) / weighted_sum
           },
           'Exp-IX' = {
             cumulative_reward[picked_arm] <- cumulative_reward[picked_arm] + 
               (current_reward / (vec_prob[picked_arm] + gamma))
             weighted_sum <- sum(exp(eta * cumulative_reward)) 
             vec_prob <- exp(eta * cumulative_reward) / weighted_sum
           })
    
    mat_prob[i,] <- vec_prob
    
    picked_arm <- sample(1:num_arms, 1, prob = vec_prob, replace = TRUE)
    chosen_arms[i] <- picked_arm
    
    object <- data[i,'Item']
    current_reward <- reward_df[reward_df$Item == object, picked_arm+1]
    
    reward_list[i] <- current_reward
    
  }
  
  data$Action <- chosen_arms
  data$Reward <- reward_list
  
  return(list(mat_prob, data))
  
}

################################################################################
# This function generates a list of list of parameters per model considered.
# With the specificity of context 'OnePerItem' that generates different eta per 
# cell.

GenEtabis <- function(contexts_name = names(Contexts),etacell = 0.03,specificeta = 0 )  {
  
  if (specificeta == 0){
    lengths <- c(9,1,2,2,4,4)
    eta <- lapply(lengths, function(len) rep(etacell, len))
  }
  
  else{
    lengths <- c(1,2,2,4,4)
    eta1<-c()
    for (k in 0:8){
      eta1 <- c(eta1,etacell/10+k*0.007)
    }
    
    eta <- list()
    eta[[1]] <- eta1
    for (k in 1:length(lengths)){
      eta[[k+1]] <- rep(etacell,lengths[k]) 
    }
  }
  
  names(eta) <- contexts_name
  
  return(eta)
}

################################################################################
# This function generates the data of one synthetic agent as a function of the
# model considered.

GenDataModel <- function(bandit_type = 'Exp3', data, eta, gamma = 0,
                           reward_df, contexts_name = names(Contexts)) {
  
  generateddatapermodel_list <- lapply(contexts_name, function(model) {
    
    selected_syntheticdata <- PartitionningData(data, model)
    
    generateddata <- lapply(seq_along(selected_syntheticdata), function(k) {
      generateddatapersubset <- GenBanditAlgo(bandit_type = 'Gradient', 
                                              selected_syntheticdata[[k]], 
                                              eta[[model]][[k]], gamma = 0,
                                              reward_df)
      
      generateddatapersubset[[2]]$row_number <- as.numeric(
        row.names(generateddatapersubset[[2]]))
      
      return(generateddatapersubset[[2]])
      
    } )
    
    combined_df <- do.call(rbind, generateddata)
    
    generateddatafinal <- combined_df[order(combined_df$row_number), ]
    
    generateddatapermodel <- generateddatafinal[, -c(4, 5)]
    
    return(generateddatapermodel)
    
  } )
  
  names(generateddatapermodel_list) <- contexts_name
  
  return(generateddatapermodel_list)
  
}

################################################################################
# This function takes as input a number of agents and applies the GenDataModel
# to each agent to generate a list of size the number of contexts
# of lists of size the number of agents of dataframes. Each list in the list is  
# the result of generated actions under model.

GenDataModelAllAgents <- function(num_syntheticagent,
                                     bandit_type = 'Exp3', data, eta,
                                     gamma = 0, reward_df,
                                     contexts_name = names(Contexts)) {
  # Initialize list of lists
  generateddatapermodelallagent_listoflist <- vector("list", length = length(Contexts))
  names(generateddatapermodelallagent_listoflist) <- contexts_name
  
  # Loop through each synthetic agent
  for (k in 1:num_syntheticagent) {
    generateddatapermodel_list <- GenDataModel(bandit_type = bandit_type,
                                                 data[[k]], eta, gamma = 0,
                                                 reward_df)
    
  # Loop through each model and add the generated data to the corresponding list
    for (i in seq_along(contexts_name)) {
      model <- contexts_name[i]
      if (is.null(generateddatapermodelallagent_listoflist[[model]])) {
        generateddatapermodelallagent_listoflist[[model]] <- list()
      }
      generateddatapermodelallagent_listoflist[[model]][[k]] <- 
        generateddatapermodel_list[[model]]
    }
  }
  
  return(generateddatapermodelallagent_listoflist)
}

################################################################################
# This function computes the likelihood of the observations for the subset of
# the partition

LogLikelihood <- function(data, arm_prob) { 
  
  num_trials <- length(data[,'Item'])
  
  log_likelihood <- 0
  
  for (i in 1:num_trials) {
    
    current_arm <- data[i,'Action']
    
    log_likelihood <- log_likelihood + log(arm_prob[i, current_arm])
  }
  
  return(log_likelihood)
  
}

################################################################################
# This function computes the maximum likelihood estimator of the observations
# for one subset of the partition using DEoptim.

MLEgen<-function(data, bandit_type = 'Exp3', range) {
  
  fn <-function(delta){
    
    -LogLikelihood(data = data, arm_prob = BanditAlgo(bandit_type, data = data, 
                                         delta,gamma=0))
  }
  
  opti=DEoptim(fn,range[1],range[2],DEoptim.control(itermax = 20,
                                                    trace = FALSE))
  estimator =opti$optim$bestmem[[1]]
  
  llmax = opti$optim$bestval[[1]]
  
  return(list(llmax,estimator))
  
}  

################################################################################
# The function Criterion computes the penalized Criterion as a function
# of a parameter c for each model for the penalized log likelihood procedure.
# The function Criterionbis does the same thing but for the real data. 


Criterion <- function(num_syntheticagent, dataloglikelihood, c, contexts = Contexts) {
  criterion <- list()
  for (k in names(contexts)) {
    criterion[[k]] <- list()
    for (j in 1:num_syntheticagent) {
      criterion[[k]][[j]] <- list()
      for (i in names(contexts)) {
        horizon <- dataloglikelihood[[k]][[j]][[i]][[3]]
        penalty <- length(contexts[[i]]) * c * log(horizon)^2 / horizon
        criterionvalue <- dataloglikelihood[[k]][[j]][[i]][[2]] / horizon + penalty
        criterion[[k]][[j]][[i]] <- criterionvalue
      }
    }
  }
  return(criterion)
}


Criterionbis <- function(num_agent = num_agents, dataloglikelihood, 
                         c, contexts = Contexts) {
  criterion <- list()
  for (j in 1:num_agent) {
    criterion[[j]] <- list()
    for (i in names(contexts)) {
      horizon <- dataloglikelihood[[j]][[i]][[3]]
      penalty <- length(contexts[[i]]) * c * log(horizon)^2 / horizon
      criterionvalue <- dataloglikelihood[[j]][[i]][[2]] / horizon + penalty
      criterion[[j]][[i]] <- criterionvalue
    }
  }
  return(criterion)
}

################################################################################

############################## Pre-Initialization ##############################



{Contexts <- list(
  
  OnePerItem = list(1, 2, 7, 8, 11, 12, 13, 14, 15),
  
  OneForAll = list(All = c(1, 2, 7, 8, 11, 12, 13, 14, 15)),
  
  byShape = list(Square = c(1, 2, 7, 8),
                 Circle = c(11, 12, 13, 14, 15)
  ),
  
  byPattern = list(Plain = c(1, 2, 13, 14),
                   Stripped = c(7, 8, 11, 12, 15)
  ),
  
  
  byShape_Exceptions_Sep = list(Square = c(1, 2, 7),
                                Circle = c(11, 12, 14, 15),
                                Exception_1 = 8,
                                Exception_2 = 13
  ),
  
  
  byPattern_Exceptions_Sep = list(Plain = c(1, 2, 13),
                                  Stripped = c(8, 11, 12, 15),
                                  Exception_1 = 7,
                                  Exception_2 = 14
  )
  
)}


################################################################################
#
#                                  Main code
#
################################################################################

################################################################################

################################################################################
#
#                                  Synthetic Data
#
################################################################################

################################################################################
# Procedure that creates the csv.files with a sequence of contexts. 

#Possibility to create files with different actions sequence length
#num_trials_list <- c(500)
#num_syntheticagent <- 100

## DO NOT RUN: Rename the files
#for (num_trials in num_trials_list){
  # Create a unique filename using the num_trials value
#  filename <- paste0("./syntheticdatabis/databis_", num_trials, ".csv")
  
  # Call the GenDataFile function with the unique filename
#  GenDataFilebis(num_trials, 1, "./syntheticdatabis/")
  
#  file.rename("./syntheticdatabis/databis_1.csv", filename)
#}


alltrials_list <- list.files(path = "./syntheticdatabis",
                               pattern = '\\.csv$',
                               full.names = TRUE) # List all files of csv type inside
# the working directory.

alltrials_syntheticfile_list  <- lapply(alltrials_list, function(file) {
  read.csv(file)
} ) 


  
################################################################################
# GENERATE SYNTHETIC DATA: FOR ALL MODELS FOR 100 SYNTHETIC AGENTS PER SAMPLE
# SIZE, APPLY GenDataModelAllAgents to generate sequence of actions associated
# to each model


reward_df <-CodingReward(1,0)
num_syntheticagent <- 100
replication_factor <- num_syntheticagent
replicated_list <- lapply(alltrials_syntheticfile_list, 
                          function(df) replicate(replication_factor, df, simplify = FALSE))
names <- names(Contexts)
base_path <- "./syntheticdatabis"

create_folders <- function(base_path, names) {
  for (name in names) {
    folder_path_bis <- file.path(base_path, name)
    folder_path <- paste0(folder_path_bis, "_", "bis")
    if (!dir.exists(folder_path)) {
      dir.create(folder_path, recursive = TRUE)
      cat("Dossier cr��:", folder_path, "\n")
    } else {
      cat("Dossier d�j� existant:", folder_path, "\n")
    }
  }
}

## DO NOT RUN: Create the files of generated data per model

#create_folders(base_path, names)


#eta <- GenEtabis(contexts_name = names(Contexts),eta=0.03,specificeta = 1)

#for (j in 1:length(num_trials_list)){
#  filtered_syntheticdata <- FilterContext(replicated_list[[j]],Contexts)
#  allagents <- GenDataModelAllAgents(num_syntheticagent,
#                                      bandit_type="Gradient",
#                                      filtered_syntheticdata,eta,gamma=0,
#                                        reward_df)


# SAVE THE allagents FILES IN THE FOLLOWING FILES

#  for (name in names) {
    # Create folder path for each name
#    folder_path <- paste0(base_path,'/', name,'_','bis')
    
    # Create the directory if it does not exis1t
#    if (!dir.exists(folder_path)) {
#      dir.create(folder_path, recursive = TRUE)
#    }
    
    # Loop through synthetic agents
#    for (i in 1:num_syntheticagent) { 
      # Define the file name and path
#      file_name <- paste0("databis_", j, "_", i, ".csv")
#      file_path <- file.path(folder_path, file_name)
      
      # Write the data frame to a CSV file
#      write.csv(allagents[[name]][[i]], file_path, row.names = FALSE)
#    }
#  }
#}

################################################################################
# ESTIMATION PROCEDURE: LOAD THE PREVIOUS FILES OF SYNTHETIC DATA


examplefile_list <- list.files(path = "./syntheticdatabis/byPattern_bis",
                                 pattern = '\\.csv$',
                                 full.names = TRUE) # List all files of csv type inside
# the working directory.

exampledata_list <- lapply(examplefile_list, function(file) {
  read.csv(file)
} ) 
  

#num_syntheticagent <- 100
#reward_df <-CodingReward(1,0)
#range <- c(0,1)
#modelname <- names(Contexts)



# DO NOT RUN: computes the estimates for each model, and saves it in the file
# Datalikelihood100agents6modelsetafixed500horizon.Rdata
#
#listestimateperdatageneratedmodel <- list()
#for (model in modelname) {
#       index <- which(modelname == model)
#       print(index/length(modelname))
#       folderpath <- paste0('./syntheticdatabis','/', model, '_','bis')
#       syntheticfile_list <- list.files(path = folderpath,
#                                        pattern = '\\.csv$',
#                                        full.names = TRUE) # List all files of csv type inside
      
#       synthetic_data <- lapply(syntheticfile_list, function(file) {
#        read.csv(file)
#       } ) 
#       filtered_data <- FilterContext(synthetic_data, Contexts)
      
      
#       listperagent <- list()
#       for(i in 1:num_syntheticagent){
#        listpermodel <- list()
#        for (modelbis in modelname){
#          selected_syntheticdata <- PartitionningData(filtered_data[[i]],
#                                                      modelbis)
#          list_estimate <- c()
#          list_loglikelihoodestimate <- c()
#          for (j in 1:length(selected_syntheticdata)){
#            estimate <- MLEgen(selected_syntheticdata[[j]],bandit_type = 'Gradient',
#                             range)
#            list_loglikelihoodestimate <- c(list_loglikelihoodestimate,estimate[[1]])
#            list_estimate <- c(list_estimate,estimate[[2]])
#          }
#          listpermodel[[modelbis]] <- list(list_estimate,
#                                           sum(list_loglikelihoodestimate),
#                                           length(filtered_data[[i]][,1]))
#        }
#        listperagent[[i]] <- listpermodel
#      }
#      listestimateperdatageneratedmodel[[model]] <- listperagent
#}



# Save the list to the file
#save(listestimateperdatageneratedmodel,file='Datalikelihood100agents6modeletabis500horizon.Rdata')

#Put the filepath where the file Datalikelihood100agents6modeletabis500horizon.Rdata is saved
load("./Datalikelihood100agents6modeletabis500horizon.Rdata")




num_syntheticagent <- 100
reward_df <-CodingReward(1,0)
range <- c(0,1)
modelname <- names(Contexts)
grid <- seq(0.001,0.2,0.002)
count <- matrix(0,ncol=length(modelname),nrow=length(grid))
syntheticagentlist <- c()

for (j in 1:num_syntheticagent){
  element <- rep(j,length(modelname)) 
  syntheticagentlist <- c(syntheticagentlist,element)
}

cgradient_df <- data.frame(synthetic_agent = syntheticagentlist, 
                           initial_model = rep(modelname),
                           final_model = rep(0,length(modelname)*num_syntheticagent))

for (nparam in 1:length(grid))
{
   
  critere <- Criterion(num_syntheticagent,listestimateperdatageneratedmodel,
                       grid[nparam],contexts = Contexts[modelname])
  for (nmodel in 1:length(modelname))
  {
    for (i in 1:num_syntheticagent)
    {
      mineta <- which.min(critere[[modelname[nmodel]]][[i]])
      cgradient_df$final_model[cgradient_df$initial_model==modelname[nmodel] 
                               & cgradient_df$synthetic_agent==i]<-mineta
      if(mineta!=nmodel)
      {
        count[nparam,nmodel]=count[nparam,nmodel]+1
      }
    }
  }
  
}

matrix_data <- count/100  # 10 rows, 6 columns

# Initialize an empty matrix to store the smoothed values
smoothed_data <- matrix(NA, nrow = nrow(matrix_data), ncol = ncol(matrix_data))


# Apply LOESS smoothing to each column
for (i in 1:ncol(matrix_data)) {
  # Prepare data for loess
  x <- 1:nrow(matrix_data)
  y <- matrix_data[, i]
  
  # Apply loess smoothing
  loess_fit <- loess(y ~ x)
  smoothed_data[, i] <- predict(loess_fit)
}

average_curve <- rowMeans(smoothed_data, na.rm = TRUE)

# Plot the smoothed curves
colors <- c("#F564E3","#336699","#009900","#F8766D","#00BFC4","#CC9966")
matplot(grid,smoothed_data, type = "l", lwd = 2, lty = 1, col = colors, xlab = "", ylab = "", main = "")
lines(grid, average_curve, col = "black", lwd = 2, lty = 2)


legend_labels <- c(names(Contexts), "Average")
legend_colors <- c(colors, "black")
legend_line_types <- c(rep(1, 6), 2)
legend_line_widths <- c(rep(1, 6), 2)

legend("topright", legend = legend_labels, col = legend_colors, 
       lty = legend_line_types, lwd = legend_line_widths, cex = 0.5)


################################################################################
# Box plot of the errors for the optimal choice of c in average. The last plot
# shows that the optimal c is c = 0.012.

param = 0.012
syntheticagentlist <- c()

for (j in 1:num_syntheticagent){
  element <- rep(j,length(modelname)) 
  syntheticagentlist <- c(syntheticagentlist,element)
}

cgradient_df <- data.frame(synthetic_agent = syntheticagentlist, 
                           initial_model = rep(modelname),
                           final_model = rep(0,length(modelname)*num_syntheticagent))

critere <- Criterion(num_syntheticagent,listestimateperdatageneratedmodel,
                       param,contexts = Contexts[modelname])
for (nmodel in 1:length(modelname))
{
    for (i in 1:num_syntheticagent)
    {
      mineta <- which.min(critere[[modelname[nmodel]]][[i]])
      cgradient_df$final_model[cgradient_df$initial_model==modelname[nmodel] 
                               & cgradient_df$synthetic_agent==i]<-modelname[[mineta]]
    }
}

summarized_df <- cgradient_df %>%
  group_by(initial_model, final_model) %>%
  summarise(count = n()) %>%
  ungroup()

summarized_df <- summarized_df %>%
  rename(Initial_model = initial_model,
         Models = final_model,
         Final_model = count)


ggplot(summarized_df, aes(fill=Models, y=Final_model, x=Initial_model)) + 
  geom_bar(position="fill", stat="identity")+
  theme(legend.position = "right",
      legend.text = element_text(size = 6),  
      axis.text = element_text(size = 6),    
      plot.title = element_text(size = 5)) 



################################################################################
################################################################################
################################################################################
#                           HOLD OUT PROCEDURE 


examplefile_list <- list.files(path = "./syntheticdatabis/byPattern_bis",
                               pattern = '\\.csv$',
                               full.names = TRUE) # List all files of csv type inside
# the working directory.

exampledata_list <- lapply(examplefile_list, function(file) {
  read.csv(file)
} ) 

samplesizes <- c(20,50,100,150,200,250)
num_syntheticagent <- 100
reward_df <-CodingReward(1,0)
range <- c(0,1)
modelname <- names(Contexts)



################################################################################
# DO NOT RUN: procedure that computes the different estimators for the training
# data and save the different files.


#for (samplesize in samplesizes){
#listestimateperdatageneratedmodel <- list()
#for (model in modelname) {
#  index <- which(modelname == model)
#  print(index/length(modelname))
  
#  folderpath <- paste0('./syntheticdatabis','/', model, '_','bis')
#  syntheticfile_list <- list.files(path = folderpath,
#                                   pattern = '\\.csv$',
#                                   full.names = TRUE) # List all files of csv type inside
  
#  synthetic_data <- lapply(syntheticfile_list, function(file) {
#    read.csv(file)
#  } ) 
  
  #select only the first samplesize trials to do parameter estimation
#  filtered_databis <- FilterContext(synthetic_data, Contexts)
#  filtered_data <- lapply(filtered_databis, head, samplesize)
  
#  listperagent <- list()
#  for(i in 1:num_syntheticagent){
#    listpermodel <- list()
#    for (modelbis in modelname){
#      selected_syntheticdata <- PartitionningData(filtered_data[[i]],
#                                                  modelbis)
#      list_estimate <- c()
#      list_loglikelihoodestimate <- c()
#      for (j in 1:length(selected_syntheticdata)){
#        estimate <- MLEgen(selected_syntheticdata[[j]],bandit_type = 'Gradient',
#                           range)
#        list_loglikelihoodestimate <- c(list_loglikelihoodestimate,estimate[[1]])
#        list_estimate <- c(list_estimate,estimate[[2]])
#      }
#       listpermodel[[modelbis]] <- list(list_estimate,
#                                      sum(list_loglikelihoodestimate),
#                                       length(filtered_data[[i]][,1]))
#     }
#    listperagent[[i]] <- listpermodel
#   }
#  listestimateperdatageneratedmodel[[model]] <- listperagent
#}



# Save the list to the file
#filename <- paste0('holdoutbis100agents6models','_','horizon','_',samplesize,'.Rdata')
#save(listestimateperdatageneratedmodel,file=filename)
#}

################################################################################
# Load the files that have been saved

loadRData <- function(fileName){
  #loads an RData file, and returns it
  load(fileName)
  get(ls()[ls() != "fileName"])
}


base_path = ""
files <- c(paste0(base_path, 'holdoutbis100agents6models_horizon_20.RData'), 
           paste0(base_path, 'holdoutbis100agents6models_horizon_50.RData'), 
           paste0(base_path, 'holdoutbis100agents6models_horizon_100.RData'), 
           paste0(base_path, 'holdoutbis100agents6models_horizon_150.RData'), 
           paste0(base_path, 'holdoutbis100agents6models_horizon_200.RData'), 
           paste0(base_path, 'holdoutbis100agents6models_horizon_250.RData'))

# Corresponding new names for the nested lists
new_names <- c("trainingdata20", 
               "trainingdata50", 
               "trainingdata100", 
               "trainingdata150", 
               "trainingdata200", 
               "trainingdata250")

# Loop through the files and assign new names
for (i in seq_along(files)) {
  # Load the RData file and get the loaded object
  loaded_object <- loadRData(files[i])
  
  # Assign the loaded object to a new name
  assign(new_names[i], loaded_object)
}


################################################################################
# compute the estimation error on the training data and compute the 
# loglikelihood on the testing data.



alltrainingdata <- list(trainingdata20,trainingdata50,trainingdata100,
                        trainingdata150,trainingdata200,trainingdata250)
samplesizes <- c('20','50', '100', '150', '200', '250')
names(alltrainingdata) <- samplesizes
modelname <- names(Contexts)
num_syntheticagent <- 100
eta <- GenEtabis(contexts_name = names(Contexts),etacell=0.03,specificeta = 1)


################################################################################
# DO NOT RUN: procedure to compute the holdout estimators for each training data
# sample size and save the different files.

#alldataholdout <- list()
#for (samplesize in samplesizes){
#  persamplesizeholdout <- list()
#  for (model in modelname) {
#    index <- which(modelname == model)
#    print(index/length(modelname))
#    folderpath <- paste0('./syntheticdatabis','/', model, '_','bis')
#    syntheticfile_list <- list.files(path = folderpath,
#                                     pattern = '\\.csv$',
#                                     full.names = TRUE) # List all files of csv type inside
    
#    synthetic_data <- lapply(syntheticfile_list, function(file) {
#        read.csv(file)
#    } ) 
    
    # select all the trials to compute the log likelihood on the remaining set of
    # data
#    filtered_data <- FilterContext(synthetic_data, Contexts)
    
#    listperagent <- list()
#    for(i in 1:num_syntheticagent){
#      listpermodel <- list()
#      for (modelbis in modelname){
#        selected_syntheticdata <- PartitionningData(filtered_data[[i]],
#                                                    modelbis)
#        list_error <- c()
#        list_loglikelihood <- c()
#        for (j in 1:length(selected_syntheticdata)){
#          estimate <- alltrainingdata[[samplesize]][[model]][[i]][[modelbis]][[1]][[j]]
#          data <- selected_syntheticdata[[j]]
#          arm_prob <- BanditAlgo(bandit_type = 'Gradient', data = data, 
#                                           estimate,gamma=0)
#          likelihoodfullset <- -LogLikelihood(data = data, arm_prob)
#          list_loglikelihood <- c(list_loglikelihood,likelihoodfullset)
#          list_error <- c(list_error,abs(estimate-eta[[modelbis]][[j]])/eta[[modelbis]][[j]])
#        }
#        trainingset_likelihood <- alltrainingdata[[samplesize]][[model]][[i]][[modelbis]][[2]]
#        testingset_likelihood <- sum(list_loglikelihood)-trainingset_likelihood
#        listpermodel[[modelbis]] <- list(mean(list_error),
#                                         testingset_likelihood,
#                                         length(filtered_data[[i]][,1]))
#      }
#      listperagent[[i]] <- listpermodel
#    }
#   persamplesizeholdout[[model]] <- listperagent
#  }
#  alldataholdout[[samplesize]] <- persamplesizeholdout
#}

base_path <- ""
file_name <- paste0(base_path,'alldataholdoutbis.RData')
file_namebis <- paste0(base_path,'Datalikelihood100agents6modeletabis500horizon.Rdata')
#save(alldataholdout,file=file_name)
load(file_name)
load(file_namebis)


################################################################################
# BoxPlot of the error for the OneForAll model and for the OnePerItem 
# model for all samplesize


errorOnePerItem_df <- data.frame(matrix(NA, nrow = num_syntheticagent, ncol = length(samplesizes)))
errorOneForAll_df <- data.frame(matrix(NA, nrow = num_syntheticagent, ncol = length(samplesizes)))

colnames(errorOnePerItem_df) <- samplesizes
colnames(errorOneForAll_df) <- samplesizes
errorOnePerItem_df[[as.character(500)]] <- rep(0,num_syntheticagent)
errorOneForAll_df[[as.character(500)]] <- rep(0,num_syntheticagent)

for (samplesize in samplesizes) {
  for (i in 1:num_syntheticagent) {
    # Assign values to errorOnePerItem_df
    errorOnePerItem_df[i, samplesize] <- alldataholdout[[as.character(samplesize)]]$OnePerItem[[i]]$OnePerItem[[1]]
    
    # Assign values to errorOneForAll_df
    errorOneForAll_df[i, samplesize] <- alldataholdout[[as.character(samplesize)]]$OneForAll[[i]]$OneForAll[[1]]
  }
}

for (i in 1:num_syntheticagent) {
  # Assign values to errorOnePerItem_df
  estimateOnePerItem <- listestimateperdatageneratedmodel$OnePerItem[[i]]$OnePerItem[[1]]
  estimateOneForAll <- listestimateperdatageneratedmodel$OneForAll[[i]]$OneForAll[[1]]
  errorOnePerItem <- mean(abs(estimateOnePerItem-eta[['OnePerItem']])/eta[['OnePerItem']])
  errorOneForAll <- mean(abs(estimateOneForAll-eta[['OneForAll']])/eta[['OneForAll']][1])
  errorOnePerItem_df[i, as.character(500)] <- errorOnePerItem
  errorOneForAll_df[i, as.character(500)] <- errorOneForAll
}


df1_long <- gather(errorOneForAll_df, key = "Column", value = "Value")
df2_long <- gather(errorOnePerItem_df, key = "Column", value = "Value")


combined_data <- rbind(cbind(df1_long, Group = "OneForAll"), cbind(df2_long, Group = "OnePerItem"))


combined_plot <- ggplot(combined_data, aes(x = factor(Column, levels = unique(Column)), y = Value, fill = Group)) +
  geom_boxplot() +
  labs(title = "", x = "", y = "") +
  theme_minimal()+
  theme(legend.position = c(0.8, 0.8),
        axis.text.x = element_text(size = 15),
        axis.text.y = element_text(size = 12),
        legend.text = element_text(size=15))


print(combined_plot)


################################################################################
# Holdout model selection from the likelihood of the testing set

grid <- c(20,50,100,150,200,250)
count_holdout <- matrix(0,ncol=length(modelname),nrow=length(grid))
syntheticagentlist <- c()

for (j in 1:num_syntheticagent){
  element <- rep(j,length(modelname)) 
  syntheticagentlist <- c(syntheticagentlist,element)
}

holdoutgradient_df <- data.frame(synthetic_agent = syntheticagentlist, 
                           initial_model = rep(modelname),
                           final_model = rep(0,length(modelname)*num_syntheticagent))

for (nparam in 1:length(grid))
{
  
  critere <- Criterion(num_syntheticagent,alldataholdout[[as.character(grid[nparam])]],
                       0,contexts = Contexts[modelname])
  for (nmodel in 1:length(modelname))
  {
    for (i in 1:num_syntheticagent)
    {
      mineta <- which.min(critere[[modelname[nmodel]]][[i]])
      holdoutgradient_df$final_model[holdoutgradient_df$initial_model==modelname[nmodel] 
                               & holdoutgradient_df$synthetic_agent==i]<-mineta
      if(mineta!=nmodel)
      {
        count_holdout[nparam,nmodel]=count_holdout[nparam,nmodel]+1
      }
    }
  }
  
}

average_curveholdout <- rowMeans(count_holdout/100, na.rm = TRUE)
colors <- c("#F564E3","#336699","#009900","#F8766D","#00BFC4","#CC9966")
# Plot the smoothed curves
matplot(grid/500,count_holdout/100, type = "l",lwd = 2, lty = 1, col = colors, 
        xlab = "", ylab = "", main = "")
lines(grid/500, average_curveholdout, col = "black", lwd = 2, lty = 2)


legend_labels <- c(names(Contexts), "Average")
legend_colors <- c(colors, "black")
legend_line_types <- c(rep(1, 6), 2)
legend_line_widths <- c(rep(1, 6), 2)

legend("topleft", legend = legend_labels, col = legend_colors, 
       lty = legend_line_types, lwd = legend_line_widths, cex = 0.4)


################################################################################
# Box plot of the errors for the optimal choice of N and c in average. The last plot
# shows that the optimal N (training data sample size) is N=250 and c = 0.012.

param = 0.012
syntheticagentlist <- c()

for (j in 1:num_syntheticagent){
  element <- rep(j,length(modelname)) 
  syntheticagentlist <- c(syntheticagentlist,element)
}

cgradient_df <- data.frame(synthetic_agent = syntheticagentlist, 
                           initial_model = rep(modelname),
                           final_model = rep(0,length(modelname)*num_syntheticagent))

critere <- Criterion(num_syntheticagent,listestimateperdatageneratedmodel,
                     param,contexts = Contexts[modelname])
for (nmodel in 1:length(modelname))
{
  for (i in 1:num_syntheticagent)
  {
    mineta <- which.min(critere[[modelname[nmodel]]][[i]])
    cgradient_df$final_model[cgradient_df$initial_model==modelname[nmodel] 
                             & cgradient_df$synthetic_agent==i]<-modelname[[mineta]]
  }
}

for (i in 1:length(cgradient_df[,1])){
  if (cgradient_df[i,2] == names(Contexts)[6]){
    cgradient_df[i,2] <- 'byPatternExc'
  }
  if (cgradient_df[i,3] == names(Contexts)[6]){
    cgradient_df[i,3] <- 'byPatternExc'
  }
}

for (i in 1:length(cgradient_df[,1])){
  if (cgradient_df[i,2] == names(Contexts)[5]){
    cgradient_df[i,2] <- 'byShapeExc'
  }
  if (cgradient_df[i,3] == names(Contexts)[5]){
    cgradient_df[i,3] <- 'byShapeExc'
  }
}


summarized_df <- cgradient_df %>%
  group_by(initial_model, final_model) %>%
  summarise(count = n()) %>%
  ungroup()

summarized_df <- summarized_df %>%
  rename(Initial_model = initial_model,
         Models = final_model,
         Final_model = count)


N=250
syntheticagentlist <- c()

for (j in 1:num_syntheticagent){
  element <- rep(j,length(modelname)) 
  syntheticagentlist <- c(syntheticagentlist,element)
}

holdoutgradient_df <- data.frame(synthetic_agent = syntheticagentlist, 
                                 initial_model = rep(modelname),
                                 final_model = rep(0,length(modelname)*num_syntheticagent))


critereholdout <- Criterion(num_syntheticagent,alldataholdout[[as.character(N)]],
                     0,contexts = Contexts[modelname])
for (nmodel in 1:length(modelname))
{
  for (i in 1:num_syntheticagent)
  {
    mineta <- which.min(critereholdout[[modelname[nmodel]]][[i]])
    holdoutgradient_df$final_model[holdoutgradient_df$initial_model==modelname[nmodel] 
                                   & holdoutgradient_df$synthetic_agent==i]<-modelname[[mineta]]
    if(mineta!=nmodel)
    {
      count_holdout[nparam,nmodel]=count_holdout[nparam,nmodel]+1
    }
  }
}

for (i in 1:length(holdoutgradient_df[,1])){
  if (holdoutgradient_df[i,2] == names(Contexts)[6]){
    holdoutgradient_df[i,2] <- 'byPatternExc'
  }
  if (holdoutgradient_df[i,3] == names(Contexts)[6]){
    holdoutgradient_df[i,3] <- 'byPatternExc'
  }
}

for (i in 1:length(holdoutgradient_df[,1])){
  if (holdoutgradient_df[i,2] == names(Contexts)[5]){
    holdoutgradient_df[i,2] <- 'byShapeExc'
  }
  if (holdoutgradient_df[i,3] == names(Contexts)[5]){
    holdoutgradient_df[i,3] <- 'byShapeExc'
  }
}





summarizedholdout_df <- holdoutgradient_df %>%
  group_by(initial_model, final_model) %>%
  summarise(count = n()) %>%
  ungroup()

summarizedholdout_df <- summarizedholdout_df %>%
  rename(Initial_model = initial_model,
         Models = final_model,
         Final_model = count)




plot1 <- ggplot(summarizedholdout_df, aes(fill = Models, y = Final_model, x = Initial_model)) + 
  geom_bar(position = "fill", stat = "identity") +
  theme(legend.position = "none",
        legend.text = element_text(size = 7),
        axis.title = element_blank(),
        axis.text = element_text(size = 7),
        plot.title = element_text(size = 8,hjust = 0.5)) +
  labs(title = "Hold-out criterion")+ theme(axis.text.x = element_text(angle = 30,hjust=1))

# Plot for summarizedholdout_df
plot2 <- ggplot(summarized_df, aes(fill = Models, y = Final_model, x = Initial_model)) + 
  geom_bar(position = "fill", stat = "identity") +
  theme(legend.position = "right",
        legend.text = element_text(size = 7),
        axis.title = element_blank(),
        axis.text = element_text(size = 7),
        plot.title = element_text(size = 8,hjust = 0.5)) +
  labs(title = "Penalized MLE criterion")+ theme(axis.text.x = element_text(angle = 30,hjust=1))

# Arrange plots horizontally
column_widths <- c(1, 1.4)

# Combine plots with adjusted scaling between them
combined_plots <- grid.arrange(plot1, plot2, ncol = 2, widths = column_widths)


################################################################################
#                     EXPERIMENTAL DATA



reward_df <-CodingReward(1,0)
range <- c(0,1)
modelname <- names(Contexts)
base_path <- ""

################################################################################
# Penalized MLE estimators

# Loads a file pmlerealdata.Rdata that records the estimates for each model for
# the real data. We cannot give the original data to do this, but the procedure
# is exactly the same as for synthetic data. 
#
#

file_name <- paste0(base_path,'realdatamle.RData')
load(file_name)


################################################################################
#
# Loads a file that computes the partial log-likelihood for the Hold-out 
# procedure and the associated estimated parameters for the real for the 
# experimental data with training sample size equals to half of the sample size.
# We cannot provide the code and the data for this procedure, we simply give the
# output result. The file is called realdata_holdout_trainingset.Rdata


base_path <- ""
file_name <- paste0(base_path,'realdata_holdout_trainingset.RData')
load(file_name)


################################################################################
# Hold model selection for the experimental data
#
# Loads a file realdata_holdout_testingset that computes the log-likelihood on
# the testing set, as well as the estimation error on the parameters on the 
# training set.

base_path <- ""
file_name <- paste0(base_path,'realdata_holdout_testingset.RData')
load(file_name)
num_agents <- 176


critere <- Criterionbis(num_agents,realdata_holdout_testingset,
                        0,contexts = Contexts[modelname])
holdoutgradientrealdata_df <- data.frame(agents = 1:num_agents, 
                                         Models = rep(0,num_agents),Holdout_real_data = rep('Real data',num_agents))

for (i in 1:num_agents)
{
  mineta <- which.min(critere[[i]])
  holdoutgradientrealdata_df[i,2]<-modelname[[mineta]]
}

for (i in 1:length(holdoutgradientrealdata_df[,1])){
  if (holdoutgradientrealdata_df[i,2] == names(Contexts)[5]){
    holdoutgradientrealdata_df[i,2] <- 'byShapeExc'
  }
}

for (i in 1:length(holdoutgradientrealdata_df[,1])){
  if (holdoutgradientrealdata_df[i,2] == names(Contexts)[6]){
    holdoutgradientrealdata_df[i,2] <- 'byPatternExc'
  }
}



################################################################################
# Penalized model selection for the experimental data



base_path <- ""
file_name <- paste0(base_path,'realdatamle.RData')
load(file_name)

param = 0.012
cgradientrealdata_df <- data.frame(agents = 1:num_agents, 
                           Models = rep(0,num_agents),pMLE_real_data = rep('Real data',num_agents))

critere <- Criterionbis(num_agents,realdatamle,
                     param,contexts = Contexts[modelname])

for (i in 1:num_agents)
{
    mineta <- which.min(critere[[i]])
    cgradientrealdata_df[i,2]<-modelname[[mineta]]
}

for (i in 1:length(cgradientrealdata_df[,1])){
  if (cgradientrealdata_df[i,2] == names(Contexts)[5]){
    cgradientrealdata_df[i,2] <- 'byShapeExc'
  }
}

for (i in 1:length(cgradientrealdata_df[,1])){
  if (cgradientrealdata_df[i,2] == names(Contexts)[6]){
    cgradientrealdata_df[i,2] <- 'byPatternExc'
  }
}


ggplot(cgradientrealdata_df, aes(fill = Models, y = agents,x= pMLE_real_data)) + 
  geom_bar(position = "fill", stat = "identity", width = 0.5) +  # Adjust the width of the bars as needed
  theme(legend.position = "right",
        legend.text = element_text(size = 6),
        axis.title.x = element_blank(),  # Remove x-axis label
        axis.title.y = element_blank(),  # Remove y-axis label
        axis.text = element_text(size = 6),
        plot.title = element_text(size = 5))

################################################################################
################################################################################
# Single BoxPlot for the hold-out with N=250, the penalized MLE with c=0.012,
# the real data penalized mle criterion and holdoutcriterion.

plot3 <- ggplot(holdoutgradientrealdata_df, aes(fill = Models, y = agents,x= Holdout_real_data)) + 
  geom_bar(position = "fill", stat = "identity", width = 0.5) +  # Adjust the width of the bars as needed
  theme(legend.position = "none",
        legend.text = element_text(size = 9),
        axis.title = element_blank(),
        axis.text.y = element_blank(),
        axis.text = element_text(size = 10),
        plot.title = element_text(size = 10, hjust = 0.5))+
  theme(
    panel.grid.major = element_blank(),  # Remove major grid lines
    panel.grid.minor = element_blank()   # Remove minor grid lines
  )+labs(title = expression(bold("c:") ~ "Hold-out"))+ theme(axis.text.x = element_text(angle = 30,hjust=1))



plot4 <- ggplot(cgradientrealdata_df, aes(fill = Models, y = agents,x= pMLE_real_data)) + 
  geom_bar(position = "fill", stat = "identity", width = 0.5) +  # Adjust the width of the bars as needed
  theme(legend.position = "right",
        legend.text = element_text(size = 9),
        axis.title = element_blank(),
        axis.text.y = element_blank(),
        axis.text = element_text(size = 10),
        plot.title = element_text(size = 10, hjust = 0.5))+
  theme(
    panel.grid.major = element_blank(),  # Remove major grid lines
    panel.grid.minor = element_blank()   # Remove minor grid lines
  )+labs(title = expression(bold("d:") ~ "P.MLE"))+ theme(axis.text.x = element_text(angle = 30,hjust=1))

plot1 <- ggplot(summarizedholdout_df, aes(fill = Models, y = Final_model, x = Initial_model)) + 
  geom_bar(position = "fill", stat = "identity") +
  theme(legend.position = "none",
        legend.text = element_text(size = 7),
        axis.title = element_blank(),
        axis.text = element_text(size = 9),
        plot.title = element_text(size = 10,hjust = 0.5)) +
  labs(title = expression(bold("a:")~"Hold-out criterion"))+ theme(axis.text.x = element_text(angle = 30,hjust=1))


plot2 <- ggplot(summarized_df, aes(fill = Models, y = Final_model, x = Initial_model)) + 
  geom_bar(position = "fill", stat = "identity") +
  theme(legend.position = "none",
        legend.text = element_text(size = 7),
        axis.title = element_blank(),
        axis.text.y = element_blank(),
        axis.text = element_text(size = 9),
        plot.title = element_text(size = 10,hjust = 0.5)) +
  labs(title = expression(bold("b:")~"Penalized MLE criterion"))+ theme(axis.text.x = element_text(angle = 30,hjust=1))

# Arrange plots horizontally
column_widths <- c(1.6, 1.5,0.4,1)

# Combine plots with adjusted scaling between them
combined_plots <- grid.arrange(plot1, plot2,plot3,plot4, ncol = 4, widths = column_widths)


